import tensorflow as tf

# disable eager_execution(tf 2.1.0 version error solution)
# eager_execution 에러 경고창을 없애줍니다.(주로 tf 1.x.x 버전에서 쓰이던 구문을 tf 2.x.x에 맞춰사용하려면
#   compat.v1을 함수 사이에 넣어줘야하는데 이로써 발생하는 에러를 없애줍니다.)
tf.compat.v1.disable_eager_execution()

# delete the current graph
# 현재 그래프를 제거해줍니다.(중복방지)
tf.compat.v1.reset_default_graph()

# data doesn't saved, so re-define x_data and y_data
# x_data와 y_data는 저장하지 않았습니다. 때문에 다시 선언해줘야 합니다.
x_data = [[1, 2], [2, 3], [3, 1], [4, 3], [5, 3], [6, 2]]
y_data = [[0], [0], [0], [1], [1], [1]]

# graph can use call the other variables(ex)placeholder, model, ...)
# tensor를 불러올 때 필요한 함수입니다.(그래프 형식으로 받아옵니다.)
graph = tf.compat.v1.get_default_graph()

# import graph
# 저장된 그래프를 불러옵니다.
imported_graph = tf.compat.v1.train.import_meta_graph('mymodel.meta')

# ready to use Session
# 세션을 준비한 후 실행합니다.
with tf.compat.v1.Session() as sess:
    # 불러온 그래프를 restore합니다.
    imported_graph.restore(sess, './mymodel')

    # W, b를 save할 때 'name=' 했던 이름으로 불러옵니다.
    W, b = sess.run(['W:0', 'b:0'])
    print('weights = ', W)
    print('bias = ', b)

    # 나머지 여타 tensor들도 'name=' 했던 이름으로 불러옵니다.
    X = graph.get_tensor_by_name('X:0')
    Y = graph.get_tensor_by_name('Y:0')
    model = graph.get_tensor_by_name('model:0')
    cost = graph.get_tensor_by_name('cost:0')
    prediction = graph.get_tensor_by_name('pred:0')
    accuracy = graph.get_tensor_by_name('acc:0')
    train = tf.compat.v1.train.GradientDescentOptimizer(0.01).minimize(cost)

    for step in range(1001):
        cost_val, train_val = sess.run([cost, train], feed_dict={X: x_data, Y: y_data})
        print(step, cost_val)

    # Testing
    h, c, a = sess.run([model, prediction, accuracy], feed_dict={X: x_data, Y: y_data})
    print("\nModel: ", h, "\nCorrect: ", c, "\nAccuracy: ", a)
