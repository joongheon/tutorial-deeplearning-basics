import tensorflow as tf

tf.compat.v1.disable_eager_execution()
w1 = tf.compat.v1.placeholder(tf.float32, name='w1')
w2 = tf.compat.v1.placeholder(tf.float32, name='w2')
b1 = tf.compat.v1.Variable(2.0, dtype=tf.float32, name='bias')
feed_dict = {'w1': 4.0, 'w2': 8.0}

w3 = w1 + w2
w4 = tf.multiply(w3, b1, name='op_to_restore')
sess = tf.compat.v1.Session()
sess.run(tf.compat.v1.global_variables_initializer())

saver = tf.compat.v1.train.Saver()

result = sess.run(w4, {w1: feed_dict['w1'], w2: feed_dict['w2']})
print(result)

saver.save(sess, 'my_test_model', global_step=1000)
