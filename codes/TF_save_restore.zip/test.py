import tensorflow as tf

tf.compat.v1.disable_eager_execution()

x_data = [[1, 2], [2, 3], [3, 1], [4, 3], [5, 3], [6, 2]]
y_data = [[0], [0], [0], [1], [1], [1]]
X = tf.compat.v1.placeholder(tf.float32, shape=[None, 2])
Y = tf.compat.v1.placeholder(tf.float32, shape=[None, 1])
W = tf.Variable(tf.compat.v1.random_normal([2, 1]), name='W')
b = tf.Variable(tf.compat.v1.random_normal([1]), name='b')

init_op = tf.compat.v1.global_variables_initializer()

with tf.compat.v1.Session() as sess:
    sess.run(init_op)
    a_out, b_out = sess.run([W, b])

    saver = tf.compat.v1.train.Saver()
    for i, var in enumerate(saver._var_list):
        print('Var {}: {}'.format(i, var))