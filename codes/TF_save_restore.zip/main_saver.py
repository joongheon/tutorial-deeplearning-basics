import tensorflow as tf

# disable eager_execution(tf 2.1.0 version error solution)
# eager_execution 에러 경고창을 없애줍니다.(주로 tf 1.x.x 버전에서 쓰이던 구문을 tf 2.x.x에 맞춰사용하려면
#   compat.v1을 함수 사이에 넣어줘야하는데 이로써 발생하는 에러를 없애줍니다.)
tf.compat.v1.disable_eager_execution()

# define variables and placeholder
# placeholder와 변수들을 선언 및 초기화 해줍니다.
x_data = [[1, 2], [2, 3], [3, 1], [4, 3], [5, 3], [6, 2]]
y_data = [[0], [0], [0], [1], [1], [1]]
X = tf.compat.v1.placeholder(tf.float32, shape=[None, 2], name="X")
Y = tf.compat.v1.placeholder(tf.float32, shape=[None, 1], name="Y")
W = tf.Variable(tf.compat.v1.random_normal([2, 1]), name='W')
b = tf.Variable(tf.compat.v1.random_normal([1]), name='b')

# call tf.Saver()
# Saver()함수를 불러옵니다.
saver = tf.compat.v1.train.Saver()

# set model, cost, opt
# 모델과, 오차함수, 최적화 함수 까지 세팅해줍니다.
model = tf.sigmoid(tf.add(tf.matmul(X, W), b), name="model")
cost = tf.reduce_mean((-1) * Y * tf.math.log(model) + (-1) * (1 - Y) * tf.math.log(1 - model), name="cost")
train = tf.compat.v1.train.GradientDescentOptimizer(0.01).minimize(cost)

# set prediction and accuracy
# pred와 acc까지 세팅해줍니다.
prediction = tf.cast(model > 0.5, dtype=tf.float32, name="pred")
accuracy = tf.reduce_mean(tf.cast(tf.equal(prediction, Y), dtype=tf.float32), name="acc")

# ready to use Session
# 세션을 준비한 후 실행합니다.
with tf.compat.v1.Session() as sess:
    # initialize global variables
    # 변수들을 초기화 합니다.
    sess.run(tf.compat.v1.global_variables_initializer())
    # Training
    for step in range(1001):
        cost_val, train_val = sess.run([cost, train], feed_dict={X: x_data, Y: y_data})
        print(step, cost_val)
    # Testing
    h, c, a = sess.run([model, prediction, accuracy], feed_dict={X: x_data, Y: y_data})
    print("\nModel: ", h, "\nCorrect: ", c, "\nAccuracy: ", a)
    # save variables
    # 각 변수들을 저장합니다. 출력문엔 어느 경로에 저장했는지를 출력해줍니다.
    saved_path = saver.save(sess, './mymodel')
    print('Model saved in {}'.format(saved_path))

# when you want see the saved variables, use this
# saver = tf.compat.v1.train.Saver()
# for i, var in enumerate(saver._var_list):
#     print('Var {}: {}'.format(i, var))